"""
Get the CAVEclient version
===========================

This example shows how to get the version of the CAVEclient package.
"""

# %% 
# Import the CAVEclient package

import caveclient as cc

# %% 
# Import the CAVEclient package

print(cc.__version__)
